from root import *

if __name__ == '__main__':

    ventana = GrupoA()
    ventana.ventana_padre()